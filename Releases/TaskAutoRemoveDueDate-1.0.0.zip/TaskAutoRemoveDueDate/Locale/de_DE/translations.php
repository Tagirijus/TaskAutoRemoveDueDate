<?php

return array(
    'Remove the tasks due date when the task is moved to a certain column' => 'Lösche das Fälligkeitsdatum eines Tasks, wenn dieser in eine bestimmte Spalte verschoben wird'
);
